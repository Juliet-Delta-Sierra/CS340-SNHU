#Jacob Simmons, CS340, 4-1 Assignment, 04Jun2023

from pymongo import MongoClient
from bson.objectid import ObjectId
from pprint import pprint


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self,USER = 'aacUser', PASS = 'SNHU1234'):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31379
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            insertIsGood = self.database.animals.insert_one(data)  # data should be dictionary
            if insertIsGood != 0: #checking insertIsGood
                return True
            else:
                return False
        else:
            raise Exception("No data to create record, enter data")

# Create method to implement the R in CRUD.
    def read(self,findData:dict):
        if findData is not None:
            #foundData = self.database.animals.find(findData, {"_id": False})
            foundData = self.collection.find(findData)

            #Print Read Results
            #for i in foundData:
                #print(i)

            #Re-establish pointer
            #foundData = self.database.animals.find(findData, {"_id": False})

            #Determine number of elements
            #count = 0
            #for instance in foundData:
                #count += 1
        else:
            #foundData = self.database.animals.find({}, {"_id": False})
            raise Exception("Something broke in the read .py file.")

        return foundData

#Create method to implement the U in CRUD
    def update(self,inputData, newData):
        if inputData is not None:
            result = self.database.animals.update_many(inputData, {"$set": newData})
        else:
            raise Exception("Check data entry and try again")
        return result

#Create method to implement the D in CRUD
    def delete(self, removeData):
        if removeData is not None:
             #Determine number of elements
            count = 0
            for instance in removeData:
                count += 1
            data = self.database.animals.delete_many(removeData)
            return count
        else:
            raise Exception("No data providied")
            